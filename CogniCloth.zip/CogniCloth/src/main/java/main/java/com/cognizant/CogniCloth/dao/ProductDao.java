package main.java.com.cognizant.CogniCloth.dao;

public interface ProductDao {

}
