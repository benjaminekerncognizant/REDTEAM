package main.java.com.cognizant.CogniCloth.dao;

public class SupplierDao {

}
