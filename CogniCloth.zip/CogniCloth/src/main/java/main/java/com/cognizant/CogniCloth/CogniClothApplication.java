package main.java.com.cognizant.CogniCloth;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class CogniClothApplication {
@Autowired
private Environment env;

	public static void main(String[] args) 
	{
		/*
		 * Product prod1 = new Product(); Category cat = new Category("pants");
		 * JdbcCategorySearch cat1 = new JdbcCategorySearch();
		 * cat1.select(cat);
		 * JdbcProductSearch productsearch = new JdbcProductSearch();
		 * productsearch.select(prod1);
		 * System.out.println(prod1.toString());
		 * //System.out.println(cat1.toString());
		 */	
	
		
		
		
		
	}

}
