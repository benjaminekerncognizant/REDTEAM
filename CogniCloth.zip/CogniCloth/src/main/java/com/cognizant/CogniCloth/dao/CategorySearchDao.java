package com.cognizant.CogniCloth.dao;

public interface CategorySearchDao {

}
