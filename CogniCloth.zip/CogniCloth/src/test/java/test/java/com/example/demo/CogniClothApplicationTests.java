package test.java.com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CogniClothApplicationTests {

	@Test
	void contextLoads() {
	}

}
