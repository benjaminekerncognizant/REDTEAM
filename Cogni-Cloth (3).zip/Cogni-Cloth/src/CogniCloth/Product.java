package CogniCloth;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Product {
	
	private static int currentID = 0;
	private int productID;
	private int supplierID;
	private long categoryID;
	private float price;
	private String productName;
	private String productDescription;
	private static List<Product> allProducts = new ArrayList<Product>();

	public Product() {
		this.productID = ++currentID;
		allProducts.add(this);
	}
	
	public Product(int supplierID, long categoryID, float price, String productName,
			String productDescription) {
		super();
		this.supplierID = supplierID;
		this.categoryID = categoryID;
		this.price = price;
		this.productName = productName;
		this.productDescription = productDescription;
		this.productID = ++currentID;
		allProducts.add(this);
	}

	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public int getSupplierID() {
		return supplierID;
	}

	public void setSupplierID(int supplierID) {
		this.supplierID = supplierID;
	}
	
	public long getCategoryID() {
		return categoryID;
	}

	public void setCategoryID(long categoryID) {
		this.categoryID = categoryID;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	
	public static List<Product> getAllProducts() {
		return allProducts;
	}
}
